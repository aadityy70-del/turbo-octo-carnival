// Ported from PODIUM (player/service Crossfader.kt, D-77, D-92, D-96; GPL-3.0).
@file:OptIn(UnstableApi::class)

package app.aether.player

import android.os.SystemClock
import android.util.Log
import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.MediaSource
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.abs

/**
 * Crossfade: the end of one song and the start of the next overlap by [seconds].
 *
 * The queue, the session and the notification stay with the engine's one player ([main]); a second,
 * silent player ([helper]) only ever carries the outgoing song's last seconds:
 *
 * 1. A few seconds before the overlap, the helper starts the same song, silent, just ahead, and is
 *    brought exactly level with [main] by playing a little slower or faster (silent, so the change in
 *    pitch is never heard).
 * 2. At the overlap, the same audio swaps from [main] to the helper in a few milliseconds, which nobody
 *    hears; [main] moves on to the next song, silent, and the queue moves with it.
 * 3. The helper fades the old song out while [main] fades the new one in from its start, on
 *    equal-power curves; then the helper stops.
 *
 * Anything the listener does meanwhile (pause, skip, seek, a call) ends it at once: the helper stops
 * and [main] plays at full volume. When it can't be done cleanly (the song is too short, the next song
 * is the album's next track, the second player can't keep up, a DAC is playing bit-perfect) the songs
 * simply follow each other as before.
 *
 * **Carrying a song over to a better copy.** The same second player lets a song that started from its
 * own source move to a copy of the same recording found for it mid-song (lossless from one of the
 * listener's sources, say), unheard but for a short crossfade ([carry]): the helper loads that copy a
 * few seconds ahead and waits there, starts as [main] reaches that point, is lined up with the song by
 * its sound ([SoundAlignment]) and brought level, and the sound crossfades over to it. [main] then
 * plays on, silent and kept level with the helper, so the queue, position, session and lyrics stay
 * where they are. At the next pause or seek, or when the song ends, the carry ends and the engine decides
 * what [main] does ([onCarryEnded]). Crossfade at the end of a carried song works as usual, with the
 * helper fading out the copy it carries.
 *
 * Main thread only, like the players.
 */
internal class Crossfader(
    private val main: ExoPlayer,
    /** Builds the second player: the same sound path, no audio focus, no notification. */
    private val newHelper: () -> ExoPlayer,
    /** What the rules need to know about the song at a queue position of [main]. */
    private val songAt: (Int) -> CrossfadeRules.Song?,
    private val scope: CoroutineScope,
    /** True while the end of this song mustn't overlap the next (a bit-perfect route). */
    private val blocked: () -> Boolean = { false },
    /** A carried copy is now what's heard: the song's media id. */
    private val onCarrying: (String) -> Unit = {},
    /** A carry ended, or never got going. */
    private val onCarryEnded: (CarryEnd) -> Unit = {},
    /** Lines a carried copy up with the song by their sound, when both players can be measured. */
    private val soundAlignment: () -> SoundAlignment? = { null },
) {
    var seconds: Int = 0
        set(value) {
            field = value
            // Crossfade turned off leaves a carry under way alone; it needs the helper.
            if (value <= 0) {
                if (!carrying) release()
            } else {
                watch()
            }
        }

    /** Why a carry ended. */
    enum class CarryReason { PAUSED, SOUGHT, ENDED, MOVED_ON, GAVE_UP, COPY_FAILED, FAILED, CANCELLED }

    /** A carry that ended: the song's [uid], whether its copy was being [heard], and where the helper was in it. */
    data class CarryEnd(val uid: String, val reason: CarryReason, val heard: Boolean, val positionMs: Long)

    private var helper: ExoPlayer? = null
    private var watcher: Job? = null
    private var phase = Phase.IDLE

    /** Set while [main] moves to the next song itself, so the move isn't taken for the listener's. */
    private var movingOn = false

    private enum class Phase { IDLE, LEVELLING, LEVEL, FADING, CARRY_LOADING, CARRY_LEVELLING, CARRY_FADING, CARRYING }

    val carrying: Boolean
        get() = phase == Phase.CARRY_LOADING || phase == Phase.CARRY_LEVELLING || phase == Phase.CARRY_FADING || phase == Phase.CARRYING

    /** Whether the carried copy is what's heard now. */
    val carriedAudible: Boolean get() = phase == Phase.CARRYING

    init {
        main.addListener(object : Player.Listener {
            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                if (!playWhenReady) {
                    if (carrying) endCarry(CarryReason.PAUSED) else stop()
                } else {
                    watch()
                }
            }

            // A call or another app taking the sound: the second player has no focus of its own to lose.
            override fun onPlaybackSuppressionReasonChanged(playbackSuppressionReason: Int) {
                if (playbackSuppressionReason == Player.PLAYBACK_SUPPRESSION_REASON_NONE) return
                if (carrying) endCarry(CarryReason.PAUSED) else stop()
            }

            override fun onPositionDiscontinuity(oldPosition: Player.PositionInfo, newPosition: Player.PositionInfo, reason: Int) {
                when {
                    movingOn -> Unit
                    // The listener skipped or sought: whatever was under way ends.
                    reason == Player.DISCONTINUITY_REASON_SEEK -> if (carrying) endCarry(CarryReason.SOUGHT) else stop()
                    // The carried song came to its end without a crossfade: [main] has moved on.
                    reason == Player.DISCONTINUITY_REASON_AUTO_TRANSITION && carrying -> endCarry(CarryReason.ENDED)
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                if (carrying) endCarry(CarryReason.FAILED) else stop()
            }
        })
    }

    /** The second player, while one exists (the engine keeps its equaliser in step). */
    val helperPlayer: ExoPlayer? get() = helper

    /** Look, while music plays, for the moment to start. */
    private fun watch() {
        if ((seconds <= 0 && !carrying) || watcher?.isActive == true) return
        watcher = scope.launch {
            while (isActive && (seconds > 0 || carrying)) {
                tick()
                delay(if (phase == Phase.IDLE || phase == Phase.LEVEL || phase == Phase.CARRYING) TICK_MS else FAST_TICK_MS)
            }
        }
    }

    private var fadeStartedAt = 0L
    private var fadeLengthMs = 0L
    private var nextStartedAt = 0L
    private var levellingIndex = C.INDEX_UNSET

    private fun tick() {
        if (!main.playWhenReady) return
        when (phase) {
            Phase.IDLE -> {
                if (seconds <= 0) return
                val remaining = remainingMs() ?: return
                val overlap = seconds * 1_000L
                if (remaining > overlap + PREPARE_AHEAD_MS || remaining < MIN_FADE_MS) return
                if (!applies()) return
                startLevelling()
            }
            Phase.LEVELLING, Phase.LEVEL -> {
                val h = helper ?: return stop()
                if (blocked() || h.playerError != null) return stop()
                val remaining = remainingMs() ?: return stop()
                if (main.currentMediaItemIndex != levellingIndex) return stop()
                if (h.isPlaying) {
                    val drift = h.currentPosition - main.currentPosition
                    if (abs(drift) <= CrossfadeRules.IN_STEP_MS) {
                        if (h.playbackParameters.speed != 1f) h.playbackParameters = PlaybackParameters.DEFAULT
                        phase = Phase.LEVEL
                    } else {
                        h.playbackParameters = PlaybackParameters(CrossfadeRules.catchUpSpeed(drift))
                        phase = Phase.LEVELLING
                    }
                }
                when {
                    phase == Phase.LEVEL && remaining <= seconds * 1_000L -> beginFade(remaining)
                    // Couldn't get level in time: the songs just follow each other.
                    remaining < MIN_FADE_MS -> stop()
                }
            }
            Phase.FADING -> {
                val h = helper ?: return stop()
                val now = SystemClock.elapsedRealtime()
                // The old song fades out from the moment of the swap (and is silent once it ends)…
                val p = ((now - fadeStartedAt).toFloat() / fadeLengthMs).coerceIn(0f, 1f)
                h.volume = if (h.playbackState == Player.STATE_ENDED) 0f else CrossfadeRules.fadeOut(p)
                // …the new one fades in from when it really starts playing, not from the move.
                if (nextStartedAt == 0L && main.isPlaying) nextStartedAt = now
                val q = if (nextStartedAt == 0L) 0f else ((now - nextStartedAt).toFloat() / fadeLengthMs).coerceIn(0f, 1f)
                main.volume = CrossfadeRules.fadeIn(q)
                // Done once the new song is at full volume (by then the old one has faded: p ≥ q),
                // or if the new one still hasn't started long after the old one ended.
                if (q >= 1f || (nextStartedAt == 0L && now - fadeStartedAt > fadeLengthMs * 2)) finish()
            }
            Phase.CARRY_LOADING, Phase.CARRY_LEVELLING, Phase.CARRY_FADING, Phase.CARRYING -> carryTick()
        }
    }

    private fun remainingMs(): Long? {
        val duration = main.duration.takeIf { it != C.TIME_UNSET && it > 0 } ?: return null
        return duration - main.currentPosition
    }

    private fun applies(): Boolean {
        if (blocked()) return false
        val index = main.currentMediaItemIndex
        val next = main.nextMediaItemIndex
        if (index == C.INDEX_UNSET || next == C.INDEX_UNSET || next == index) return false
        val current = songAt(index) ?: return false
        return CrossfadeRules.applies(seconds, current, songAt(next), repeatOne = main.repeatMode == Player.REPEAT_MODE_ONE)
    }

    private fun startLevelling() {
        val item = main.currentMediaItem ?: return
        val h = helper ?: newHelper().also { helper = it }
        levellingIndex = main.currentMediaItemIndex
        h.volume = 0f
        h.playbackParameters = PlaybackParameters.DEFAULT
        // A little ahead of [main], to allow for its start; levelling takes care of the rest.
        h.setMediaItem(item, main.currentPosition + LEAD_MS)
        h.prepare()
        h.playWhenReady = true
        phase = Phase.LEVELLING
    }

    private fun beginFade(remaining: Long) {
        val h = helper ?: return stop()
        // The same audio, level in both players: swap it to the helper, unheard.
        h.volume = 1f
        main.volume = 0f
        fadeLengthMs = remaining.coerceAtLeast(MIN_FADE_MS)
        fadeStartedAt = SystemClock.elapsedRealtime()
        nextStartedAt = 0L
        phase = Phase.FADING
        movingOn = true
        try {
            main.seekToNextMediaItem()
        } finally {
            movingOn = false
        }
    }

    private fun finish() {
        helper?.let {
            it.playWhenReady = false
            it.stop()
            it.clearMediaItems()
        }
        phase = Phase.IDLE
        main.volume = 1f
    }

    /** End anything under way: the helper falls silent, [main] plays at full volume. */
    fun stop() {
        if (carrying) return endCarry(CarryReason.CANCELLED)
        if (phase != Phase.IDLE) finish()
        main.volume = 1f
    }

    fun release() {
        stop()
        watcher?.cancel()
        watcher = null
        helper?.release()
        helper = null
    }

    // --- Carrying a song over to a better copy ---------------------------------------------------------

    private var carryUid: String? = null
    private var carryIndex = C.INDEX_UNSET
    private var carryTargetMs = 0L
    private var carryTries = 0
    private var carryPhaseStartedAt = 0L

    /** Since when [main] has been past the copy's start without the copy able to join it (0: it isn't). */
    private var carryLateSince = 0L

    /** Where the copy's sound is, relative to [main]'s: at [main]'s position p the copy is at p + this. */
    private var carryOffsetMs = 0L
    private var alignment: SoundAlignment? = null
    private var alignListening: AutoCloseable? = null
    private var alignTries = 0
    private var alignSettled = true
    private var nextAlignAt = 0L

    /**
     * Start carrying the song [main] is playing over to [copy]: another copy of the same recording. False
     * when it can't start now (nothing else may be under way, the song must be playing, and enough of it
     * must be left); the engine then waits for a pause or a seek.
     *
     * Race-free: the copy loads [CARRY_AHEAD_MS] ahead of the song and waits there, paused and silent. It
     * joins only once it's ready where the song is; if the song gets there first, the copy keeps loading
     * and jumps forward inside what it has already loaded, rather than starting over.
     */
    fun carry(uid: String, copy: MediaSource): Boolean {
        if (phase != Phase.IDLE || !main.playWhenReady || blocked()) return false
        if (main.currentMediaItem?.mediaId != uid) return false
        val remaining = remainingMs() ?: return false
        if (remaining < CARRY_MIN_REMAINING_MS) return false
        val h = helper ?: newHelper().also { helper = it }
        carryUid = uid
        carryIndex = main.currentMediaItemIndex
        carryTries = 0
        carryLateSince = 0L
        carryTargetMs = main.currentPosition + CARRY_AHEAD_MS
        carryOffsetMs = 0L
        alignment = soundAlignment()
        alignListening = alignment?.listen()
        alignTries = 0
        alignSettled = alignment == null
        h.volume = 0f
        h.playbackParameters = PlaybackParameters.DEFAULT
        // Loaded ahead and held there: it starts only once [main] gets to that point.
        h.playWhenReady = false
        h.setMediaSource(copy, carryTargetMs)
        h.prepare()
        phase = Phase.CARRY_LOADING
        carryPhaseStartedAt = SystemClock.elapsedRealtime()
        watch()
        return true
    }

    private fun carryTick() {
        val h = helper ?: return endCarry(CarryReason.GAVE_UP)
        if (main.currentMediaItemIndex != carryIndex) return endCarry(CarryReason.MOVED_ON)
        // The copy itself wouldn't play: that's the copy's doing, not the moment's.
        if (h.playerError != null) return endCarry(CarryReason.COPY_FAILED)
        val now = SystemClock.elapsedRealtime()
        // Too near the end to finish getting there: the song plays out as it is (and crossfades as usual).
        if (phase == Phase.CARRY_LOADING || phase == Phase.CARRY_LEVELLING) {
            val remaining = remainingMs()
            if (remaining == null || remaining < maxOf(CARRY_END_MS, seconds * 1_000L + PREPARE_AHEAD_MS)) return endCarry(CarryReason.GAVE_UP)
        }
        when (phase) {
            Phase.CARRY_LOADING -> {
                val position = main.currentPosition
                if (position < carryTargetMs - CARRY_START_EARLY_MS) return // still ahead of the song
                when {
                    // Ready where the song is, or just behind it: off it goes, silent, to be brought level.
                    h.playbackState == Player.STATE_READY && position - h.currentPosition <= CARRY_MISSED_MS -> {
                        h.playWhenReady = true
                        phase = Phase.CARRY_LEVELLING
                        carryPhaseStartedAt = now
                        carryLateSince = 0L
                    }
                    // The song got past the copy's start first, but what the copy has loaded reaches
                    // beyond the song: it jumps there, inside what it has, and waits again.
                    h.bufferedPosition >= position + CARRY_JUMP_LEAD_MS + CARRY_READY_MS -> {
                        carryTargetMs = position + CARRY_JUMP_LEAD_MS
                        h.seekTo(carryTargetMs)
                        carryLateSince = 0L
                    }
                    // Still loading: it's given time to catch up before trying from further ahead.
                    else -> {
                        if (carryLateSince == 0L) carryLateSince = now
                        if (now - carryLateSince > CARRY_LATE_MS) retarget(h)
                    }
                }
            }
            Phase.CARRY_LEVELLING -> {
                if (h.isPlaying) {
                    if (!alignSettled) align(now)
                    val drift = h.currentPosition - main.currentPosition - carryOffsetMs
                    if (alignSettled && abs(drift) <= CrossfadeRules.IN_STEP_MS) {
                        h.playbackParameters = PlaybackParameters.DEFAULT
                        phase = Phase.CARRY_FADING
                        fadeStartedAt = now
                        return
                    }
                    // Still silent: the helper may play a little slower or faster to get level.
                    h.playbackParameters = PlaybackParameters(CrossfadeRules.catchUpSpeed(drift))
                }
                if (now - carryPhaseStartedAt > CARRY_LEVEL_TIMEOUT_MS) endCarry(CarryReason.GAVE_UP)
            }
            Phase.CARRY_FADING -> {
                // Two copies of one recording, lined up by their sound: a short equal-power crossfade.
                val p = ((now - fadeStartedAt).toFloat() / CARRY_FADE_MS).coerceIn(0f, 1f)
                main.volume = CrossfadeRules.fadeOut(p)
                h.volume = CrossfadeRules.fadeIn(p)
                if (p >= 1f) {
                    phase = Phase.CARRYING
                    carryUid?.let(onCarrying)
                }
            }
            Phase.CARRYING -> {
                // The copy ended first (they can differ by a second or two): [main] plays the rest.
                if (h.playbackState == Player.STATE_ENDED) main.volume = 1f
                // [main] follows the helper, silently, so the position everyone sees is what's heard.
                val drift = main.currentPosition - (h.currentPosition - carryOffsetMs)
                val speed = if (abs(drift) > CrossfadeRules.IN_STEP_MS * 2) CrossfadeRules.catchUpSpeed(drift) else 1f
                if (main.playbackParameters.speed != speed) main.playbackParameters = PlaybackParameters(speed)
                // Crossfade into the next song as usual, the helper fading out the copy it carries.
                val remaining = remainingMs()
                if (seconds > 0 && remaining != null && remaining <= seconds * 1_000L && applies()) {
                    val ended = CarryEnd(carryUid.orEmpty(), CarryReason.ENDED, heard = true, positionMs = h.currentPosition)
                    carryUid = null
                    main.playbackParameters = PlaybackParameters.DEFAULT
                    beginFade(remaining)
                    onCarryEnded(ended)
                }
            }
            else -> Unit
        }
    }

    /**
     * Where the copy's sound is, once it has played long enough to tell. With nothing clear to go by
     * after a few looks, equal positions it is, as copies of one recording usually are.
     */
    private fun align(now: Long) {
        val a = alignment ?: return settleAlignment(0L)
        if (main.currentPosition - carryTargetMs < SoundAlignment.NEEDS_MS || now < nextAlignAt) return
        when (val r = a.measure(main.currentPosition)) {
            is SoundAlignment.Result.Offset -> settleAlignment(r.ms)
            SoundAlignment.Result.NotYet, SoundAlignment.Result.Unsure ->
                if (++alignTries >= ALIGN_MAX_TRIES) settleAlignment(0L) else nextAlignAt = now + ALIGN_RETRY_MS
        }
    }

    private fun settleAlignment(offsetMs: Long) {
        carryOffsetMs = offsetMs
        alignSettled = true
        alignListening?.close()
        alignListening = null
        if (offsetMs != 0L) Log.d(TAG, "the copy's sound is $offsetMs ms from the song's")
    }

    /** The copy couldn't catch up with the song where it was: it starts again from further ahead. */
    private fun retarget(h: ExoPlayer) {
        carryTries++
        val remaining = remainingMs()
        if (carryTries > CARRY_MAX_TRIES || remaining == null || remaining < CARRY_MIN_REMAINING_MS) return endCarry(CarryReason.GAVE_UP)
        carryTargetMs = main.currentPosition + CARRY_AHEAD_MS * 2
        carryLateSince = 0L
        h.seekTo(carryTargetMs)
    }

    private fun endCarry(reason: CarryReason) {
        val uid = carryUid
        val heard = phase == Phase.CARRYING || phase == Phase.CARRY_FADING
        val position = helper?.currentPosition ?: 0L
        carryUid = null
        alignListening?.close()
        alignListening = null
        alignment = null
        finish()
        if (main.playbackParameters.speed != 1f) main.playbackParameters = PlaybackParameters.DEFAULT
        // With crossfade off, the second player was only for this.
        if (seconds <= 0) {
            helper?.release()
            helper = null
        }
        uid?.let { onCarryEnded(CarryEnd(it, reason, heard, position)) }
    }

    private companion object {
        const val TICK_MS = 250L
        const val FAST_TICK_MS = 30L

        /** The helper starts levelling this long before the overlap. */
        const val PREPARE_AHEAD_MS = 4_000L
        const val LEAD_MS = 150L
        const val MIN_FADE_MS = 1_000L

        /** How far ahead of the song the copy loads and waits. */
        const val CARRY_AHEAD_MS = 6_000L

        /** Times it may start again from further ahead, when it can't catch up where it is. */
        const val CARRY_MAX_TRIES = 2

        /** How long the copy has to catch up, loading, once the song is past its start. */
        const val CARRY_LATE_MS = 12_000L

        /** A jump inside what's loaded lands this far ahead of the song… */
        const val CARRY_JUMP_LEAD_MS = 300L

        /** …and needs this much loaded beyond it to be ready at once (the player's own threshold, and some). */
        const val CARRY_READY_MS = 3_000L

        /** Not worth starting for a song's last seconds… */
        const val CARRY_MIN_REMAINING_MS = 15_000L

        /** …nor finishing getting there. */
        const val CARRY_END_MS = 8_000L
        const val CARRY_START_EARLY_MS = 40L
        const val CARRY_MISSED_MS = 400L

        /** Levelling, with time to measure where the copy's sound is. */
        const val CARRY_LEVEL_TIMEOUT_MS = 12_000L
        const val CARRY_FADE_MS = 400L
        const val ALIGN_MAX_TRIES = 4
        const val ALIGN_RETRY_MS = 300L
        const val TAG = "AetherCrossfade"
    }
}
