// Ported from PODIUM (core/lyrics, GPL-3.0), the listener's own app; package renamed for TITOPLAY.
package app.aether.core.lyrics

/*
 * Lyrics, provider-independent (LYRICS_ARCHITECTURE.md §2). A provider supplies words; Podium decides
 * how they follow the music. Synced lyrics carry the moment each line is sung; plain lyrics never
 * pretend to.
 */

/**
 * One line of synced lyrics: sung from [startMs]. An empty [text] is a gap between lines.
 * [endMs] is when the line ends, when the provider says (otherwise the next line's start bounds it);
 * [words] are the provider's own word times (enhanced LRC, Apple's TTML), empty when it only times
 * whole lines: when there are any, there is one for each of the line's words as spaces divide it.
 *
 * [background] is the answering vocal, the "(ooh)" a second voice sings over the lead: a line of its
 * own, with its own times, never nested. [opposite] is the second voice of a duet, set from the
 * other side, as Apple sets it.
 */
data class LyricsLine(
    val startMs: Long,
    val text: String,
    val endMs: Long? = null,
    val words: List<LyricsWord> = emptyList(),
    val background: LyricsLine? = null,
    val opposite: Boolean = false,
) {
    /** When the singing of this line stops, by its own times: its last word's end, or its own end. */
    val sungUntilMs: Long? get() = words.lastOrNull()?.endMs ?: endMs
}

/**
 * A word of a line, sung from [startMs] (to [endMs], when the provider says), only from a provider
 * that times words. A long word may come in [syllables], each a stretch of its [text] with times
 * of its own ("e" and "nough"); empty when the word is timed whole.
 */
data class LyricsWord(
    val startMs: Long,
    val text: String,
    val endMs: Long? = null,
    val syllables: List<LyricsSyllable> = emptyList(),
)

/** One separately timed piece of a word: its characters [startChar] until [endChar], sung from [startMs] to [endMs]. */
data class LyricsSyllable(val startMs: Long, val endMs: Long, val startChar: Int, val endChar: Int)

sealed interface Lyrics {
    /**
     * Lines with times, in order. Never empty. [estimated]: the times are Podium's ([LyricsFormatter]),
     * paced across the song or repaired, not the provider's — the screen says so.
     */
    data class Synced(val lines: List<LyricsLine>, val estimated: Boolean = false) : Lyrics {
        init {
            require(lines.isNotEmpty()) { "synced lyrics need lines" }
        }

        /** Whether the provider timed the words, not only the lines. */
        val wordTimed: Boolean get() = !estimated && lines.any { it.words.isNotEmpty() }
    }

    /** Words without times: shown as they are, moved through by the listener. Never empty. */
    data class Plain(val lines: List<String>) : Lyrics {
        init {
            require(lines.isNotEmpty()) { "plain lyrics need lines" }
        }
    }

    /** The provider knows the song has no words. */
    data object Instrumental : Lyrics
}

/** What Podium knows about the song whose lyrics it wants — metadata only, never a provider's id. */
data class LyricsRequest(
    /** Stable identity of the song for caching (a source-qualified track id). */
    val key: String,
    val title: String,
    val artist: String,
    val album: String? = null,
    val durationMs: Long? = null,
    /** The recording's code, when its source knows it (a file's tag): some libraries file by it. */
    val isrc: String? = null,
)

/** The answer the screen shows. */
sealed interface LyricsResult {
    data class Found(val lyrics: Lyrics, val provider: LyricsAttribution) : LyricsResult

    /** Nothing confident enough: better no lyrics than another song's. */
    data object NotFound : LyricsResult

    /** The listener hasn't agreed yet to send song details to the lyrics service (D-11). */
    data object NeedsConsent : LyricsResult

    data object Offline : LyricsResult

    /** The service failed, timed out or answered nonsense; trying again later may work. */
    data object Failed : LyricsResult

    /** The service asked Podium to slow down; it can be asked again in [retryInMs] (D-84). */
    data class RateLimited(val retryInMs: Long) : LyricsResult
}

/** Who the words came from, for the small credit in Settings and on the lyrics screen's details. */
data class LyricsAttribution(val name: String, val url: String)
