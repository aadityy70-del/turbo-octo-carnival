// Ported from PODIUM (core/lyrics, GPL-3.0), the listener's own app; package renamed for TITOPLAY.
package app.aether.core.lyrics

/**
 * When each word of a synced line appears (LYRICS_ARCHITECTURE.md §5.1): the words come in as they
 * are sung, not the whole line at once.
 *
 * - **Timed by the provider** (enhanced LRC word stamps, or words in LRCLIB's `lyricsfile`): those
 *   times, kept in order and inside the line.
 * - **Timed by the line only** (most lyrics): an estimate inside the line's real window — from its
 *   start to its end (or the next line's start) — shared out by syllables, with a short pause after
 *   punctuation, and never slower than [MAX_MS_PER_SYLLABLE] so a line followed by an instrumental
 *   break doesn't trickle its last words across the break. The first word always appears exactly
 *   when the line starts; only the order and pace inside the line are estimated.
 */
object WordTiming {

    /** Singing rarely spends longer on a syllable; beyond this the line just waits fully shown. */
    const val MAX_MS_PER_SYLLABLE = 380L

    /** Without an end time, the words are all in by this share of the gap to the next line. */
    private const val SHARE_OF_GAP = 0.85

    /** A line with nothing after it gets this much per syllable. */
    private const val LAST_LINE_MS_PER_SYLLABLE = 300L

    /** The words of [line] as the screen shows them (split on spaces). */
    fun words(line: LyricsLine): List<String> = line.text.trim().split(SPACE_RUN).filter { it.isNotEmpty() }

    /** Whether [line]'s word times are estimated rather than the provider's. */
    fun isEstimated(line: LyricsLine): Boolean = line.words.size != words(line).size

    /** When each word of [line] appears; [nextStartMs] is the next line's start, if any. */
    fun starts(line: LyricsLine, nextStartMs: Long?): List<Long> {
        val words = words(line)
        if (words.isEmpty()) return emptyList()
        if (!isEstimated(line)) {
            // The provider's times, kept in order and never before the line itself starts.
            var last = line.startMs
            return line.words.map { w -> maxOf(last, w.startMs).also { last = it } }
        }
        val weights = weights(words)
        val total = weights.sum()
        val span = span(line, nextStartMs, total)
        var before = 0.0
        return weights.map { w ->
            (line.startMs + span * (before / total)).toLong().also { before += w }
        }
    }

    /**
     * When [line] has been sung through: its last word's end. With the provider's word times, the
     * line's own end (or its last word plus a syllable-paced share, never past the next line);
     * otherwise the end of the estimated span [starts] spreads the words across. Never before the
     * last word starts, never after [nextStartMs]. Used by the Continuous line theme to know when
     * the pen leaves a phrase (LYRICS_ARCHITECTURE.md §12.3).
     */
    fun end(line: LyricsLine, nextStartMs: Long?): Long {
        val words = words(line)
        val starts = starts(line, nextStartMs)
        val last = starts.lastOrNull() ?: return line.startMs
        val end = if (!isEstimated(line)) {
            val lastWord = (syllables(words.last()) * LAST_LINE_MS_PER_SYLLABLE)
            line.endMs?.takeIf { it > last } ?: (last + lastWord)
        } else {
            (line.startMs + span(line, nextStartMs, weights(words).sum())).toLong()
        }
        return if (nextStartMs != null && nextStartMs > last) minOf(end, nextStartMs).coerceAtLeast(last) else end.coerceAtLeast(last)
    }

    private fun weights(words: List<String>): List<Double> = words.mapIndexed { i, word ->
        syllables(word) + if (i > 0 && words[i - 1].last() in PAUSE_AFTER) 0.5 else 0.0
    }

    /** The estimate's span: the line's real window, but never slower than [MAX_MS_PER_SYLLABLE]. */
    private fun span(line: LyricsLine, nextStartMs: Long?, total: Double): Double {
        val window = when {
            line.endMs != null && line.endMs > line.startMs -> line.endMs - line.startMs
            nextStartMs != null && nextStartMs > line.startMs -> ((nextStartMs - line.startMs) * SHARE_OF_GAP).toLong()
            else -> (total * LAST_LINE_MS_PER_SYLLABLE).toLong()
        }
        return minOf(window.toDouble(), total * MAX_MS_PER_SYLLABLE)
    }

    /** A word, or one character of a phrase in a script written without spaces, and when it's sung. */
    data class Unit(val text: String, val startMs: Long)

    /**
     * What a line is sung in, one piece at a time: its words, except that a phrase in a script written
     * without spaces (Chinese, Japanese, Thai) comes a character at a time, as it's sung there (a run
     * of Latin letters inside one stays whole, and punctuation stays with the character before it).
     * Each piece starts when the provider timed it, where it timed its syllables, or at its share of
     * its word's time.
     */
    fun units(line: LyricsLine, nextStartMs: Long?): List<Unit> {
        val words = words(line)
        if (words.isEmpty()) return emptyList()
        val starts = starts(line, nextStartMs)
        val end = end(line, nextStartMs)
        val timed = !isEstimated(line)
        val out = ArrayList<Unit>(words.size)
        words.forEachIndexed { i, word ->
            val start = starts[i]
            if (word.none(Scripts::unspaced)) {
                out += Unit(word, start)
                return@forEachIndexed
            }
            val until = starts.getOrNull(i + 1) ?: end
            val pieces = characters(word)
            val syllables = if (timed) line.words[i].syllables else emptyList()
            pieces.forEachIndexed { j, (text, at) ->
                val own = syllables.firstOrNull { at >= it.startChar && at < it.endChar }?.startMs
                val share = start + (until - start).coerceAtLeast(0) * j / pieces.size
                out += Unit(text, maxOf(start, own ?: share))
            }
        }
        return out
    }

    /** A phrase in pieces: each unspaced character (with punctuation after it), each run of anything else. */
    private fun characters(word: String): List<Pair<String, Int>> {
        val out = ArrayList<Pair<String, Int>>()
        var i = 0
        while (i < word.length) {
            val from = i
            val c = word[i]
            if (Scripts.unspaced(c) && !punctuation(c)) {
                i++
                // A surrogate pair, a combining mark, and any punctuation after it stay with it.
                while (i < word.length && (Character.isLowSurrogate(word[i]) || Character.getType(word[i]) == Character.NON_SPACING_MARK.toInt() || punctuation(word[i]))) i++
            } else {
                while (i < word.length && !(Scripts.unspaced(word[i]) && !punctuation(word[i]))) i++
            }
            val piece = word.substring(from, i)
            if (out.isNotEmpty() && piece.all(::punctuation)) {
                // Punctuation leading nothing joins what it follows.
                val (text, at) = out.removeAt(out.lastIndex)
                out += (text + piece) to at
            } else out += piece to from
        }
        return out
    }

    private fun punctuation(c: Char): Boolean = when (Character.getType(c).toByte()) {
        Character.OTHER_PUNCTUATION, Character.START_PUNCTUATION, Character.END_PUNCTUATION, Character.INITIAL_QUOTE_PUNCTUATION,
        Character.FINAL_QUOTE_PUNCTUATION, Character.DASH_PUNCTUATION, Character.CONNECTOR_PUNCTUATION -> true
        else -> false
    }

    /** How many of the words of [line] have appeared at [positionMs]. */
    fun shown(starts: List<Long>, positionMs: Long): Int = starts.count { it <= positionMs }

    /** When the next word of [line] appears after [positionMs], or null when all have. */
    fun nextWordMs(starts: List<Long>, positionMs: Long): Long? = starts.firstOrNull { it > positionMs }

    /**
     * A rough syllable count: vowel groups (a silent final "e" doesn't count), at least one. Good
     * enough to pace "I" against "everything"; scripts without these vowels count one per word.
     */
    fun syllables(word: String): Int {
        val letters = word.lowercase().filter { it.isLetter() }
        if (letters.isEmpty()) return 1
        var groups = 0
        var inVowel = false
        for (c in letters) {
            val vowel = c in VOWELS
            if (vowel && !inVowel) groups++
            inVowel = vowel
        }
        if (groups > 1 && letters.endsWith("e") && !letters.endsWith("le") && letters.length > 3) groups--
        return groups.coerceAtLeast(1)
    }

    private val SPACE_RUN = Regex("""\s+""")
    private const val VOWELS = "aeiouyàáâãäåæèéêëìíîïòóôõöøùúûüýÿœ"
    private val PAUSE_AFTER = setOf(',', ';', ':', '.', '!', '?', '—', '–')
}

/**
 * LRCLIB's `lyricsfile` (LYRICS_ARCHITECTURE.md §4.1): a small YAML document with, per line, its text,
 * `start_ms`, `end_ms`, and — for word-synced lyrics — its words. Read for the end times (and words)
 * it adds to the LRC; a tolerant reader of just that shape, failing to an empty list.
 */
object LyricsFile {

    private data class Item(var text: String? = null, var start: Long? = null, var end: Long? = null, val words: MutableList<Item> = ArrayList())

    fun parse(text: String?): List<LyricsLine> {
        if (text.isNullOrBlank()) return emptyList()
        val items = ArrayList<Item>()
        var inLines = false
        var lineIndent = -1 // indentation of a line item's "- "
        var wordsKeyIndent = -1 // indentation of the current line's "words:" key, -1 outside a word list
        var current: Item? = null
        var word: Item? = null
        for (raw in text.lineSequence()) {
            if (raw.isBlank()) continue
            val indent = raw.length - raw.trimStart().length
            val body = raw.trim()
            if (!inLines) {
                if (body == "lines:") inLines = true
                continue
            }
            // Another top-level key ends the list.
            if (indent == 0 && !body.startsWith("-")) break
            val dash = body.startsWith("-")
            val entry = if (dash) body.removePrefix("-").trim() else body
            var target: Item?
            when {
                dash && (lineIndent < 0 || indent <= lineIndent) -> {
                    lineIndent = indent
                    current = Item().also { items += it }
                    word = null
                    wordsKeyIndent = -1
                    target = current
                }
                dash && wordsKeyIndent >= 0 && indent >= wordsKeyIndent -> {
                    word = Item().also { current?.words?.add(it) }
                    target = word
                }
                dash -> continue // some other nested list: not read
                wordsKeyIndent >= 0 && indent > wordsKeyIndent && word != null -> target = word
                else -> {
                    // A key of the line itself (also after its word list).
                    if (wordsKeyIndent >= 0 && indent <= wordsKeyIndent) {
                        wordsKeyIndent = -1
                        word = null
                    }
                    target = current
                }
            }
            val key = entry.substringBefore(':', "").trim()
            val value = entry.substringAfter(':', "").trim()
            when (key) {
                "text" -> target?.text = unquote(value)
                "start_ms" -> target?.start = value.toLongOrNull()
                "end_ms" -> target?.end = value.toLongOrNull()
                "words" -> if (target === current) {
                    wordsKeyIndent = indent
                    word = null
                }
            }
        }
        return items.mapNotNull { item ->
            val start = item.start ?: return@mapNotNull null
            LyricsLine(
                startMs = start,
                text = item.text.orEmpty(),
                endMs = item.end?.takeIf { it > start },
                words = item.words.mapNotNull { w -> w.start?.let { LyricsWord(it, w.text.orEmpty().trim()) } }.filter { it.text.isNotEmpty() },
            )
        }.sortedBy { it.startMs }
    }

    /**
     * Adds what [file] knows to [lrc]: each LRC line takes the end time (and words) of the file's
     * line starting at the same moment (within 50 ms) with the same text. Nothing else changes.
     */
    fun enrich(lrc: List<LyricsLine>, file: List<LyricsLine>): List<LyricsLine> {
        if (file.isEmpty()) return lrc
        return lrc.map { line ->
            val match = file.firstOrNull { kotlin.math.abs(it.startMs - line.startMs) <= 50 && it.text.trim() == line.text.trim() }
                ?: return@map line
            val words = if (line.words.isEmpty() && match.words.size == WordTiming.words(line).size) match.words else line.words
            line.copy(endMs = line.endMs ?: match.endMs, words = words)
        }
    }

    private fun unquote(value: String): String = when {
        value.length >= 2 && value.startsWith('\'') && value.endsWith('\'') -> value.substring(1, value.length - 1).replace("''", "'")
        value.length >= 2 && value.startsWith('"') && value.endsWith('"') -> value.substring(1, value.length - 1).replace("\\\"", "\"").replace("\\\\", "\\")
        else -> value
    }
}
