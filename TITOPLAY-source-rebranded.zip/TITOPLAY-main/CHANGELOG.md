# Changelog

All notable changes to TITOPLAY will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [2.3.0] - 2026-11-11

### Fixed
- Every page said "The music service didn't answer" on phones set to a language or country YouTube Music doesn't take (Santali, Konkani, Kashmiri, Sindhi, Dogri, Maithili, Bodo, Manipuri, Yiddish; China, Iran, Afghanistan, Myanmar and a few more), signed in or not. TITOPLAY now finds out which it was and asks without it.
- What's offered follows where you are, not where your phone is set: TITOPLAY sends the country YouTube Music finds you in, as its website does.
- A sign-in that has ended says so ("Your sign-in has ended"), instead of saying a page needs an account.
- Songs kept as M4A carry their cover, name, artist, album and words, so file managers and other players show them; a kept song's cover is fetched again if the first try fails, and is always a JPEG or PNG.
- Your own sources: one that didn't answer when TITOPLAY started (no connection yet, a slow server) was left out until TITOPLAY restarted. It's asked again when the connection comes back and every two minutes, and Settings has Try again. Adding one allows a slow server longer.
- A source that refuses says why in Settings, in its own words, and rests after refusing twice, so songs don't wait on it.

### Changed
- Your own sources are handled as BitChord's host handles them: a song's stream is asked for before the address its search row gave (kept as the fallback, so a source that only searches plays too), its songs show their covers, and one that asks to be used only with a lossless output (wired or USB headphones, HDMI, or Bluetooth on LDAC, LHDC or aptX Lossless) waits until one is connected. To tell which codec Bluetooth headphones are using, TITOPLAY asks for Nearby devices and, on Android 14 and later, for Android's one-time permission to know those headphones, both from that source's row and only when it matters.
- The player's notification wears TITOPLAY's mark instead of a play symbol.
- An artist's Albums, Singles & EPs (every "See all" of albums, playlists or artists) run down the page two to a row, as videos do, and the page is named for the shelf, the artist's name above it.

## [2.2.0] - 2026-11-11

### Fixed
- TITOPLAY closed as it opened for anyone whose history held a song with no artist named (an upload, or a song kept under 2.0): Profile assumed every play had one. It now says "None named yet", and those plays count for their artist again where the phone knows who it was.
- A song chosen with no artist (some of YouTube Music's shelves and suggestions leave it out) takes its artist from YouTube's own answer for that song, a moment after it starts: Now Playing, the notification and Profile all name who made it, with no break in the sound.
- Cover films played a middling copy (a 4.9 Mbps 1078 x 1438 film that Apple also serves at 7, 10 and 20 Mbps): every film now plays the richest copy the phone can decode within its size.

### Added
- Playlists in your YouTube Music library come into TITOPLAY's Library when you're signed in, and stay up to date; signing out takes away what the sync brought.
- Sort a playlist's songs by your order, title, artist, album, when they were added (your own playlists) or length. Each playlist keeps its own choice; a long YouTube playlist is fetched whole before it's sorted.
- A song's cover film on Now Playing plays Apple's finest copy, on mobile data too (the data saver still loads no film) (up to 2160 square, 2048 x 2732 tall), drawn down to the screen: sharper than a screen-sized copy drawn up.

## [2.1.0] - 2026-11-11

### Fixed
- A queue saved while a kept song played is mended on the next start.
- Kept songs show their name, artist and cover again on Now Playing, the mini player, the notification and Samsung's Now Bar; their covers are saved for offline.
- A page could close the app when the catalogue listed the same card twice, or an artist had two shelves of one name.
- Cover films play at their best quality for the screen from the first frame, portrait films included.
- "See all" on Trending, and on an artist's Top songs and Videos, opened empty: those are playlists, and are read as playlists now. A "See all" of songs or videos shows every one, two to a row; one YouTube Music sends empty says so.
- Now Playing's video key is one kept setting again: on, a song shows its cover and then its film at its best, and a music video plays as itself; off, just the cover.

### Changed
- A playlist's Rename, Edit and Delete live in a menu at its top; Delete asks first. Its add key is a search that opens into a field, rises to the top of the page and finds songs as you type, or says they're unavailable; the tick closes it and the page comes back as it was.
- A small arrow beside every song kept on the phone, dim while it's still coming down.
- One download disc at the foot, the number coming down written on its cover (up to 99+), sitting lower, clear of the bars.
- Playlists no longer keep new songs by themselves: your own have no keep key, and a catalogue playlist's keeps its songs once.
- Playlists from the catalogue that you saved, or kept songs from, are in your Library; offline, one with nothing kept is greyed out, and one with kept songs opens on them.
- Now Playing's print wears its tattoo again; its style is chosen in Settings, not by touching it.

### Added
- When TITOPLAY closes by itself, what went wrong is kept on the phone, and Settings lets you share it. Nothing is sent otherwise.

## [2.0.0] - 2026-11-10

TITOPLAY v2.

### Added
- **Lyrics from seven libraries:** lrc.red, BiniLyrics, BetterLyrics, LyricsPlus, Unison, LRCLIB and KuGou, asked together, the best answer kept: word by word where a library has it, by the line otherwise. Each can be switched off in Settings.
- **Verse:** a third way to draw lyrics, BitChord's, ported with only the face changed: the song as a page that's sung, each word lighting syllable by syllable behind a soft edge ahead of the voice, held notes swelling letter by letter and glowing, the lines around a step back and out of focus, the answering vocal opening beneath its line as it's sung, duets from both sides, three points counting out each break. The page moves on springs that keep their speed from one line to the next. Touch a line to go to it.
- **Words in Latin letters:** Korean, Chinese, Japanese kana and other scripts romanised on the phone, beneath each line, beside each star, or written by the pen. A Latin key on the lyrics turns it off.
- **Exact copies from your own sources:** for a song from YouTube Music, your addons are asked for the same recording first, at their best quality, and it plays in its place; YouTube Music plays what they don't have. DASH and HLS copies play. Now Playing says which source a song came from.
- **Music videos:** a video plays as video in place of its cover, its pictures following the music, at 720p (480p on the data saver).
- **Albums on Listen:** the music on your phone as albums, and the songs you've kept as albums, two shelves of their own.
- **Crossfade:** 2 to 12 seconds between songs, in Settings under Sound. Never between an album's songs that run into each other.
- **Full screen:** Android's bars hidden in Settings under Feel, the page keeping its place; a swipe from the edge brings them for a moment.
- **A better copy, mid-song:** when your own sources find the same recording after a song has begun, it goes over to that copy while it plays, lined up by its sound and handed over in a short crossfade.
- **Kept songs in your Music folder:** every kept song is a file in Music/TITOPLAY, the same audio that streamed, with its cover and words in its tags, for the file manager and any player.
- **Lyrics on the phone:** a song's own .lrc beside it, or the words inside its file, shown first.
- **Updates in the app:** a newer TITOPLAY is offered on a sheet, downloaded, checked against the release and handed to Android to install.

### Changed
- Nothing is written over covers any more: Now Playing's print and the songs on a playlist's folder are the covers as they are.
- Listen's figures change only once the page has been still for a few seconds, and hold mid-change while you touch or switch.
- An addon that answers only BitChord's own app is refused when added, with the reason.
- A song that fails mid-play is tried again from where it stopped, from another source, app or format, before you're told.
- Turning a music video off and on again carries on where it was, without stalling.

## [1.0.0] - 2026-11-09

The first release.

### Added
- **Listening:** the whole YouTube Music catalogue, as a guest or signed in; your own music by folder; songs and playlists kept for offline, with new additions picked up on Wi-Fi; your own sources by address, open media only.
- **Sound:** quality labels only when measured or verified; bit-perfect output to a USB DAC on Android 14 and later; float output with no resampling by the app.
- **Equaliser:** seven tunings, measured corrections for 39 headphones, and profiles imported from AutoEq, squig.link, Equalizer APO or Wavelet files. A boost can't clip, and with nothing chosen every sample passes through untouched.
- **Now Playing:** a seeking dial; the cover as a print, halftone, ASCII or dither; the album's film in colour where it has one, fading in an arc round the controls; lyrics as constellations or as one unbroken line.
- **Listen:** twelve statues in halftone, the dots of one flying across to become the next.
- **Downloads:** the cover carried into the foot of the screen with a ripple on arrival; several at once as a row of discs, with a list of what's coming down.
- **Profile:** most played artists, your hours as a dial, genres and habits, all worked out on the phone.
- **Cards:** a metal charge card of your profile or any song, black or silver, at 1080 by 1920.
- **Privacy:** no ads, no analytics, no tracking, no account and no server of ours.

[Unreleased]: https://github.com/GHOSTxASR/AETHER/compare/v2.3.0...HEAD
[2.3.0]: https://github.com/GHOSTxASR/AETHER/compare/v2.2.0...v2.3.0
[2.2.0]: https://github.com/GHOSTxASR/AETHER/compare/v2.1.0...v2.2.0
[2.1.0]: https://github.com/GHOSTxASR/AETHER/compare/v2.0.0...v2.1.0
[2.0.0]: https://github.com/GHOSTxASR/AETHER/compare/v1.0.0...v2.0.0
[1.0.0]: https://github.com/GHOSTxASR/AETHER/releases/tag/v1.0.0
