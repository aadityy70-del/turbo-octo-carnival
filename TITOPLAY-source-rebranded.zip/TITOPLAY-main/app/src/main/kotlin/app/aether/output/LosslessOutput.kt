// Ported from BitChord (app/.../playback/audio/LosslessOutput.kt, GPL-3.0): its decision as BitChord
// has it; package renamed for TITOPLAY, and its log line dropped (TITOPLAY keeps no logs of the listener).
package app.aether.output

import android.content.Context
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * Whether the phone has an output connected right now that can carry lossless audio: the test behind
 * an addon's `checkValidLossless`.
 *
 * Lossless here means the file's samples reach the listener's converter without being re-encoded into
 * a lossy format first. A cable does that by construction; Bluetooth only does it, or comes close
 * enough that addons asking for this accept it, on a handful of high-bitrate codecs:
 *
 *  - **Wired:** 3.5mm headphones or headset, analog/digital line out, aux.
 *  - **USB:** USB-C headphones, USB DACs and USB audio accessories.
 *  - **HDMI:** HDMI, ARC and eARC (a TV, receiver or soundbar).
 *  - **Dock:** digital and analog docks.
 *  - **Bluetooth A2DP on LDAC, LHDC (V3/V4/V5), aptX Lossless or Samsung's SSC UHQ.** SBC, AAC, aptX,
 *    aptX HD, LC3 (LE Audio) and Opus are all lossy at bitrates well below CD audio, and do not count.
 *
 * The phone's own speaker, earpiece, hearing aids, casting and BLE Audio do not count either.
 * Bluetooth is only counted when Android names the codec, which needs the Nearby devices permission on
 * Android 12+; without it the codec is unknown, and an unknown codec is reported as such rather than
 * guessed ([State.bluetoothCodecUnknown]).
 */
object LosslessOutput {

    enum class Kind { WIRED, USB, HDMI, DOCK, BLUETOOTH }

    data class State(
        val capable: Boolean = false,
        /** What qualified, when something did. */
        val via: Kind? = null,
        /** The Bluetooth codec in use, when Android named one. */
        val bluetoothCodec: String? = null,
        /** A Bluetooth output is connected but its codec could not be read: usually a missing permission. */
        val bluetoothCodecUnknown: Boolean = false,
        /** Android would name the codec once TITOPLAY is associated with the headphones ([CodecCompanion]). */
        val needsCompanion: Boolean = false,
    )

    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> = _state.asStateFlow()

    /** The answer every gate reads. False until [init] has looked. */
    val capable: Boolean get() = _state.value.capable

    private var audioManager: AudioManager? = null
    private var tracker: BluetoothAudioTracker? = null

    private val callback = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>) = recompute()
        override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>) = recompute()
    }

    fun init(context: Context) {
        if (audioManager != null) return
        val app = context.applicationContext
        val manager = app.getSystemService(AudioManager::class.java) ?: return
        audioManager = manager
        manager.registerAudioDeviceCallback(callback, Handler(Looper.getMainLooper()))
        val bluetooth = BluetoothAudioTracker(app).also { it.start() }
        tracker = bluetooth
        CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate).apply {
            launch { bluetooth.telemetry.collect { recompute() } }
            launch { bluetooth.needsCompanion.collect { recompute() } }
        }
        recompute()
    }

    /** The connected headphones' address, for [CodecCompanion]; null until Android has told it. */
    val headphonesAddress: String? get() = tracker?.activeAddress

    /** Asks Bluetooth again: after the Nearby devices permission is granted, say. */
    fun refresh() {
        tracker?.refreshCurrentDevice()
        recompute()
    }

    private fun recompute() {
        val outputs = audioManager?.getDevices(AudioManager.GET_DEVICES_OUTPUTS).orEmpty()
            .filter { it.isSink }
            .map { it.type }
            .toSet()
        val telemetry = tracker?.telemetry?.value
        val named = telemetry?.takeIf { it.hasNamedCodec }
        val decided = decide(outputs, named?.codecName, named?.sampleRateHz)
        val next = decided.copy(needsCompanion = decided.bluetoothCodecUnknown && tracker?.needsCompanion?.value == true)
        if (next != _state.value) _state.value = next
    }

    /**
     * The decision itself, from the connected output types and the Bluetooth codec Android named (null
     * if it named none), with the sample rate that codec is configured for. Pure, for tests.
     */
    internal fun decide(outputTypes: Set<Int>, bluetoothCodec: String?, bluetoothSampleRateHz: Int? = null): State {
        val cabled = when {
            outputTypes.any { it in WIRED } -> Kind.WIRED
            outputTypes.any { it in USB } -> Kind.USB
            outputTypes.any { it in HDMI } -> Kind.HDMI
            outputTypes.any { it in DOCK } -> Kind.DOCK
            else -> null
        }
        if (cabled != null) return State(capable = true, via = cabled, bluetoothCodec = bluetoothCodec)
        if (AudioDeviceInfo.TYPE_BLUETOOTH_A2DP !in outputTypes) return State()
        if (bluetoothCodec == null) return State(bluetoothCodecUnknown = true)
        val lossless = isLosslessBluetoothCodec(bluetoothCodec, bluetoothSampleRateHz)
        return State(
            capable = lossless,
            via = Kind.BLUETOOTH.takeIf { lossless },
            bluetoothCodec = bluetoothCodec,
        )
    }

    /**
     * LDAC, any LHDC generation, aptX Lossless or SSC UHQ, by the name Android reports. Samsung's codec
     * may be named for the family alone ("SSC", "Samsung Seamless") whichever mode it is in, so a
     * Samsung name without "UHQ" still counts when it runs at 88.2 kHz or above: UHQ is the only
     * Samsung mode that does.
     */
    internal fun isLosslessBluetoothCodec(name: String, sampleRateHz: Int? = null): Boolean {
        val codec = name.uppercase(Locale.ROOT)
        if ("LDAC" in codec || "LHDC" in codec || ("APTX" in codec && "LOSSLESS" in codec)) return true
        if ("UHQ" in codec) return true
        val samsung = SAMSUNG_NAMES.any { it in codec }
        return samsung && sampleRateHz != null && sampleRateHz >= 88_200
    }

    private val SAMSUNG_NAMES = listOf("SSC", "SAMSUNG", "SCALABLE", "SEAMLESS")

    // AudioDeviceInfo constants, by value so the newer ones compile into older API levels as the plain
    // ints they are; a phone that predates a type simply never reports it.
    private val WIRED = setOf(
        AudioDeviceInfo.TYPE_WIRED_HEADPHONES,
        AudioDeviceInfo.TYPE_WIRED_HEADSET,
        AudioDeviceInfo.TYPE_LINE_ANALOG,
        AudioDeviceInfo.TYPE_LINE_DIGITAL,
        AudioDeviceInfo.TYPE_AUX_LINE,
    )
    private val USB = setOf(
        AudioDeviceInfo.TYPE_USB_HEADSET,
        AudioDeviceInfo.TYPE_USB_DEVICE,
        AudioDeviceInfo.TYPE_USB_ACCESSORY,
    )
    private val HDMI = setOf(
        AudioDeviceInfo.TYPE_HDMI,
        AudioDeviceInfo.TYPE_HDMI_ARC,
        29, // TYPE_HDMI_EARC, API 31
    )
    private val DOCK = setOf(
        AudioDeviceInfo.TYPE_DOCK,
        31, // TYPE_DOCK_ANALOG, API 34
    )
}
