package app.aether

import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.Call
import okhttp3.Callback
import okhttp3.Response
import java.io.IOException
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * An OkHttp call that a coroutine's cancellation really stops: a blocking `execute` runs on to its
 * end however long the server takes, so a timeout around it waits all the same.
 */
suspend fun Call.await(): Response = suspendCancellableCoroutine { cont ->
    cont.invokeOnCancellation { runCatching { cancel() } }
    enqueue(object : Callback {
        override fun onFailure(call: Call, e: IOException) {
            if (cont.isActive) cont.resumeWithException(e)
        }

        override fun onResponse(call: Call, response: Response) {
            if (cont.isActive) cont.resume(response) else response.close()
        }
    })
}

/** How TITOPLAY names itself to the services it asks: plainly, and nothing about the listener. */
const val UserAgent = "TITOPLAY/2.3 (Android music player)"
