package app.aether.ui

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.view.HapticFeedbackConstants
import android.view.View
import android.widget.Toast
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsIgnoringVisibility
import androidx.compose.foundation.layout.statusBarsIgnoringVisibility
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import app.aether.Container
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/**
 * The way over to the sibling app (TITOPLAY), and back.
 *
 * Holding the home room for five seconds turns a ring over black and opens the
 * other app. The YouTube Music sign-in goes with it, straight to that one app
 * and nowhere else; the other app does the same on the way back. A sign-in is
 * only taken by an app that is signed out, never over one in use.
 */
object AppSwitch {
    private val SIBLINGS = listOf("dev.lelonio.square", "dev.lelonio.square.dev", "dev.lelonio.square.debug")

    const val EXTRA_COOKIE = "titoplay.cookie"

    /** True while the ring is turning, until the other app is up. */
    val spinning = mutableStateOf(false)

    fun launchIntent(context: Context): Intent? =
        SIBLINGS.firstNotNullOfOrNull { context.packageManager.getLaunchIntentForPackage(it) }

    fun begin(context: Context, view: View?): Boolean {
        if (spinning.value) return false
        if (launchIntent(context) == null) {
            Toast.makeText(context, "TITOPLAY is not installed", Toast.LENGTH_SHORT).show()
            return false
        }
        view?.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        spinning.value = true
        return true
    }

    fun go(context: Context, container: Container) {
        val intent = launchIntent(context)
        if (intent != null) {
            container.account.cookies.value?.let { intent.putExtra(EXTRA_COOKIE, it) }
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            runCatching {
                context.startActivity(intent)
                (context as? Activity)?.overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            }
        }
        spinning.value = false
    }

    /** Takes a sign-in the sibling handed over, when this app has none. */
    fun receive(container: Container, intent: Intent?) {
        val cookie = intent?.getStringExtra(EXTRA_COOKIE) ?: return
        intent.removeExtra(EXTRA_COOKIE)
        if (container.account.cookies.value == null && cookie.isNotBlank()) container.account.signIn(cookie)
    }
}

/** Held for [ms] over the first of [count] equal slots, without letting go. The touch is left alone. */
fun Modifier.holdOnFirstOf(count: Int, ms: Long = 5_000L): Modifier = composed {
    val context = LocalContext.current
    val view = LocalView.current
    pointerInput(count) {
        awaitEachGesture {
            val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
            if (down.position.x >= size.width / count.toFloat()) return@awaitEachGesture
            var lifted = false
            val stillDown = withTimeoutOrNull(ms) {
                while (!lifted) {
                    val event = awaitPointerEvent(PointerEventPass.Initial)
                    if (event.changes.none { it.pressed }) lifted = true
                }
                true
            }
            if (stillDown == null) AppSwitch.begin(context, view)
        }
    }
}

/** A ring turning over black, then the other app. */
@Composable
fun AppSwitchOverlay(container: Container) {
    if (!AppSwitch.spinning.value) return
    val context = LocalContext.current
    val turn = remember { Animatable(0f) }
    val dark = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        launch { dark.animateTo(1f, tween(450)) }
        turn.animateTo(1f, tween(1300, easing = FastOutSlowInEasing))
        delay(80)
        AppSwitch.go(context, container)
    }
    Box(
        Modifier.fillMaxSize().alpha(dark.value).background(Color.Black),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(
            Modifier.size(150.dp).graphicsLayer {
                rotationZ = turn.value * 720f
                val s = 1f - 0.25f * kotlin.math.sin(turn.value * Math.PI).toFloat()
                scaleX = s
                scaleY = s
            },
        ) {
            val stroke = 6.dp.toPx()
            drawCircle(
                brush = Brush.sweepGradient(listOf(Color(0xFF00E5FF), Color(0xFF9B5CFF), Color(0xFFFF2DAA), Color(0xFF00E5FF)), center),
                radius = size.minDimension / 2f - stroke,
                style = Stroke(stroke, cap = StrokeCap.Round),
            )
        }
    }
}

/** A soft black fade at the very top and bottom edges, so lists sink into them. */
@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
fun EdgeFades() {
    val top = WindowInsets.statusBarsIgnoringVisibility.asPaddingValues().calculateTopPadding() + 36.dp
    val bottom = WindowInsets.navigationBarsIgnoringVisibility.asPaddingValues().calculateBottomPadding() + 14.dp
    Box(Modifier.fillMaxSize()) {
        Box(
            Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .height(top)
                .background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.85f), Color.Transparent))),
        )
        Box(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .height(bottom)
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.85f)))),
        )
    }
}
